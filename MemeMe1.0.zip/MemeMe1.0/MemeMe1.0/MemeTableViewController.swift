//
//  MemeTableViewController.swift
//  MemeMe1.0
//
//  Created by Raj Balani on 30/05/19.
//  Copyright © 2019 balani. All rights reserved.
//

import Foundation
import UIKit

class MemeTableViewController:UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet var memeTableViewOutlet: UITableView!
    var memes: [Meme]! {
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.memes
        
    }
    override func viewWillAppear(_ animated: Bool) {
        self.memeTableViewOutlet.reloadData()
//        self.memeTableViewOutlet.delegate=self
//        self.memeTableViewOutlet.dataSource=self
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 1
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.memes.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "memeTableCell")!
        let meme = self.memes[(indexPath as NSIndexPath).row]
       
        
        // Set the name and image
        cell.textLabel?.text = meme.topText
        cell.imageView?.image = meme.memedImage
        
        // If the cell has a detail label, we will put the bottom text in.
        if let detailTextLabel = cell.detailTextLabel {
            detailTextLabel.text = meme.bottomText
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let detailController = self.storyboard!.instantiateViewController(withIdentifier: "MemeDetailViewController") as! MemeDetailViewController
        let meme = self.memes[(indexPath as NSIndexPath).row]
        detailController.memedImageDetailView.image = meme.originalImage
        self.navigationController!.pushViewController(detailController, animated: true)
    }
}
