//
//  Meme.swift
//  MemeMe1.0
//
//  Created by Raj Balani on 18/05/19.
//  Copyright © 2019 balani. All rights reserved.
//

import Foundation
import UIKit

struct Meme {
    var topText: String = ""
    var bottomText: String = ""
    var originalImage: UIImage?
    var memedImage: UIImage?
    let dateCreated = NSDate()
    var dateCreatedString: String {
        let dateFormatter = DateFormatter()
        
        if( dateCreated.timeIntervalSinceNow < (60*60*24) ){
            dateFormatter.timeStyle = DateFormatter.Style.short
        } else {
            dateFormatter.dateStyle = DateFormatter.Style.long
        }
        
        dateFormatter.doesRelativeDateFormatting = true
        return dateFormatter.string(from: dateCreated as Date)
    }
    
    init(topText: String, bottomText: String, originalImage: UIImage, memedImage: UIImage) {
        self.topText = topText
        self.bottomText = bottomText
        self.originalImage = originalImage
        self.memedImage = memedImage
    }
}
