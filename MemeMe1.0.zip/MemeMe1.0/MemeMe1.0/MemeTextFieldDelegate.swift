//
//  TopTextFieldDelegate.swift
//  MemeMe1.0
//
//  Created by Raj Balani on 17/05/19.
//  Copyright © 2019 balani. All rights reserved.
//

import Foundation
import UIKit

class MemeTextFieldDelegate:NSObject, UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.textAlignment = .center
        if textField.text == "TOP" || textField.text == "BOTTOM"{
            textField.text=""
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
