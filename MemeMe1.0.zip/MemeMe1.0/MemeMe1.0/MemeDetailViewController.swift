//
//  MemeDetailViewController.swift
//  MemeMe1.0
//
//  Created by Raj Balani on 30/05/19.
//  Copyright © 2019 balani. All rights reserved.
//

import Foundation
import UIKit

class MemeDetailViewController:UIViewController{
    
    @IBOutlet weak var memedImageDetailView: UIImageView!
}
