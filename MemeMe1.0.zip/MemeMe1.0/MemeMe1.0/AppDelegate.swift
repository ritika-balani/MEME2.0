//
//  AppDelegate.swift
//  MemeMe1.0
//
//  Created by Raj Balani on 17/05/19.
//  Copyright © 2019 balani. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var memes = [Meme]()
    var window: UIWindow?  


}

