//
//  SentMemesViewController.swift
//  MemeMe1.0
//
//  Created by Raj Balani on 29/05/19.
//  Copyright © 2019 balani. All rights reserved.
//

import Foundation
import UIKit

class SentMemesViewController:UIViewController{
    var memes: [Meme]! {
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.memes
    }
}
